﻿//using Nop.Web.Framework.Controllers;

namespace $safeprojectname$.Controllers
{
    public class ConfigurationController // : BasePluginController
    {
        //[AdminAuthorize]
        //[ChildActionOnly]
        //public ActionResult Configure()
        //{
        //    return View("~/Plugins/$safeprojectname$/Views/Configure.cshtml", model);
        //}
    }
}
